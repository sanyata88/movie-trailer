import fresh_tomatoes
import media
toy_story=media.Movie("Toy story","A story of a boy and his toys come to life",
                      "https://amandawinter.files.wordpress.com/2010/10/600full-toy-story-poster.jpg",
                      "https://www.youtube.com/watch?v=KYz2wyBy3kc")

avatar=media.Movie("Avatar","A marine alien on planet",
                   "http://s3.foxmovies.com/foxmovies/production/films/18/images/posters/251-asset-page.jpg",
                   "https://www.youtube.com/watch?v=5PSNL1qE6VY")

serendipity=media.Movie("Serendipity","A tale about love and luck",
                        "http://www.impawards.com/2001/posters/serendipity.jpg",
                        "https://www.youtube.com/watch?v=tC3nf6bna6s")

forest_gump=media.Movie("Forest Gump","The story depicts several decades in the life of Forrest Gump",
                        "http://www.impawards.com/1994/posters/forrest_gump.jpg",
                        "https://www.youtube.com/watch?v=YNh9Es8Ut6U")

sleepless_seattle=media.Movie("Sleepless in Seattle","A romantic comedy starring Tom Hanks and Meg Ryan",
                              "http://de1imrko8s7v6.cloudfront.net/movies/posters/sleeplessinseattle_1423269414.jpg",
                              "https://www.youtube.com/watch?v=1cB7dFW0eJs")

movies = [toy_story,avatar,serendipity,forest_gump,sleepless_seattle]
# Uses list of movie instances as input to generate an HTML file
# and open it in the browser.
fresh_tomatoes.open_movies_page(movies)
