import webbrowser
class Movie():

    VALID_RATINGS=["G","PG","PG-13","R"]
    def __init__(self,movie_title,movie_storyline,poster_image,trailer_youtube_url):
        '''The __init__ method is roughly what represents a constructor in Python.
        When it is called, it creates a space in the memory for an object, and
        passes it as the first parameter to the __init__ method. ... init is the
        constructor for a class.The self parameter refers to the instance of the
        object.Inputs here are movie_title, storyline,poster image, url of the trailer. '''
        self.title = movie_title
        self.storyline = movie_storyline
        self.poster_image_url = poster_image
        self.trailer_youtube_url = trailer_youtube_url
    def show_trailer(self):
        '''This function takes the initialised object as input and shows the trailer
        by using the webbrowser open function.webbrowser is a class in python and open is
        a function '''
        #webbrowser.open takes the url of the trailer as input and opens a window
        #in the browser to show the trailer
        webbrowser.open(self.trailer_youtube_url)
